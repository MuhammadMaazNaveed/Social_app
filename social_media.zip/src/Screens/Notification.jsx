import React from 'react';
import Sidebar from '../Component/Sidebar';
import Trending from '../Component/Trending';
import NotificationItem from '../Component/NotificationItem';
import TopBar from '../Component/TopBar';

const Notification = () => {
    return (
        <div className="container_section">
            <Sidebar />
            <hr />
            <div className="middle_part_of_container">
                <TopBar />
                <NotificationItem />
            </div>
            <hr />
            <div className="right_part_of_container">
                <Trending />
            </div>
        </div>
    )
}

export default Notification