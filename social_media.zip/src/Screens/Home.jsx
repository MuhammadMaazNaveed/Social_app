import React, { useState } from "react";
import PostSection from "../Component/PostSection";

const Home = () => {
  return <PostSection />;
};

export default Home;
