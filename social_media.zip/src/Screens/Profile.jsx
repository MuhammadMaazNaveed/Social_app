import React from "react";
import ProfileItem from "../Component/ProfileItem";
const Profile = ({ children }) => {
    return (
        <>
            <ProfileItem>
                {children}
            </ProfileItem>
        </>
    );
};

export default Profile;
