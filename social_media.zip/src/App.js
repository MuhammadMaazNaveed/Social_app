import "./App.css";
import Sidebar from "./Component/Sidebar";
import Home from "./Screens/Home";
import Profile from "./Screens/Profile";
import ProfileItem from "./Component/ProfileItem";
import PostSection from "./Component/PostSection";
import ProfileBooks from "./Component/ProfileBooks";
import Profileabout from "./Component/Profileabout";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

function App() {
  return (
    <>
      <Router>
        <Sidebar>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/dashboard" element={<Profile />} />
          </Routes>
        </Sidebar>

        <Routes>
          <Route path="/dashboard" element={<Profileabout />} />
          <Route path="/dashboard" element={<Profileabout />} />
          <Route path="/dashboard" element={<PostSection />} />
          <Route path="/dashboard" element={<ProfileBooks />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
