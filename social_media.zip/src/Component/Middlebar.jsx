import React from 'react'

const Middlebar = () => {
  return (
    <div>  <div className="middle">
      <div className="item active">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
      <div className="item">
        <p>My Feed</p>
      </div>
    </div></div>
  )
}

export default Middlebar