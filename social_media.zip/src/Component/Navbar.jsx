import React from 'react'

const Navbar = () => {
    return (
        <div className="navbar">
            <div className="logo">
                <h1>
                    Publishly
                </h1>
            </div>
            <div className="nav_list">
                <nav>
                    <ul>
                        <li><a href="/">Our Mission</a></li>
                        <li><a href="/">Features</a></li>
                        <li><a href="/">Write</a></li>
                        <li><a href="/">Sign in</a></li>
                    </ul>
                </nav>
                <button>Get Started</button>
            </div>
        </div>
    )
}

export default Navbar