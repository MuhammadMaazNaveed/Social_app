import React from 'react'; import banner from "../assests/1.png";
import { motion } from "framer-motion";

const Trending = ({ isOpen }) => {

  return (
    <motion.div animate={{ width: isOpen ? "520px" : "415px" }} className='right'>  {/* <!-- ********************************************************************* TRENDING SECTION START *********************************************************************--> */}
      <motion.div animate={{ width: isOpen ? "520px" : "415px" }} className="profile_path">
        <div className="image">
          <img src={banner} alt="" />
        </div>
        <div className="profile_name">
          <h1>Welcome back!</h1>
          <h2>Deepankar Ahlawat</h2>
        </div>
      </motion.div>
      <div className="trending_section">
        <div className="heading">
          <h1>Trending this week</h1>
        </div>
        <div className="trending_list">
          <div className="item">
            <div className="left_section">
              <div className="image">
                <img src={banner} alt="" />
              </div>
              <div className="content">
                <p>March 20</p>
                <span>5 mins read</span>
              </div>
            </div>
            <div className="right_section">
              <div className="upper">
                <div className="profile">
                  <div className="image">
                    <img src={banner} alt="" />
                  </div>
                  <div className="text">
                    <p>Siddharth Mishra</p>
                    <span> from</span>
                    <p>Cricbuzz</p>
                    <i className="fa-sharp fa-regular fa-circle-check"></i>
                  </div>
                </div>
                <div className="play">
                  <i className="fa-solid fa-circle-play"></i>
                </div>
              </div>
              <div className="trending_middle">
                <h1>
                  Off the Beaten Path: Exploring Hidden Gems in Europe
                </h1>
              </div>
              <div className="bottom">
                <div className="button_group">
                  <button>Travel</button>
                </div>
                <div className="icons">
                  <i className="fa-sharp fa-regular fa-bookmark"></i>
                  <i className="fa-solid fa-ellipsis"></i>
                </div>
              </div>
            </div>
          </div>
          <div className="item">
            <div className="left_section">
              <div className="image">
                <img src={banner} alt="" />
              </div>
              <div className="content">
                <p>March 20</p>
                <span>5 mins read</span>
              </div>
            </div>
            <div className="right_section">
              <div className="upper">
                <div className="profile">
                  <div className="image">
                    <img src={banner} alt="" />
                  </div>
                  <div className="text">
                    <p>Siddharth Mishra</p>
                    <span> from</span>
                    <p>Cricbuzz</p>
                    <i className="fa-sharp fa-regular fa-circle-check"></i>
                  </div>
                </div>
                <div className="play">
                  <i className="fa-solid fa-circle-play"></i>
                </div>
              </div>
              <div className="trending_middle">
                <h1>
                  Off the Beaten Path: Exploring Hidden Gems in Europe
                </h1>
              </div>
              <div className="bottom">
                <div className="button_group">
                  <button>Travel</button>
                </div>
                <div className="icons">
                  <i className="fa-sharp fa-regular fa-bookmark"></i>
                  <i className="fa-solid fa-ellipsis"></i>
                </div>
              </div>
            </div>
          </div>
          <div className="item">
            <div className="left_section">
              <div className="image">
                <img src={banner} alt="" />
              </div>
              <div className="content">
                <p>March 20</p>
                <span>5 mins read</span>
              </div>
            </div>
            <div className="right_section">
              <div className="upper">
                <div className="profile">
                  <div className="image">
                    <img src={banner} alt="" />
                  </div>
                  <div className="text">
                    <p>Siddharth Mishra</p>
                    <span> from</span>
                    <p>Cricbuzz</p>
                    <i className="fa-sharp fa-regular fa-circle-check"></i>
                  </div>
                </div>
                <div className="play">
                  <i className="fa-solid fa-circle-play"></i>
                </div>
              </div>
              <div className="trending_middle">
                <h1>
                  Off the Beaten Path: Exploring Hidden Gems in Europe
                </h1>
              </div>
              <div className="bottom">
                <div className="button_group">
                  <button>Travel</button>
                </div>
                <div className="icons">
                  <i className="fa-sharp fa-regular fa-bookmark"></i>
                  <i className="fa-solid fa-ellipsis"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* <!-- ********************************************************************* TRENDING SECTION END *********************************************************************--> */}
        {/* <!-- ********************************************************************* AUTHOR SECTION START *********************************************************************--> */}
        <div className="heading">
          <h1>Top Authors this week</h1>
        </div>
        <div className="author">
          <div className="items">
            <div className="profile">
              <div className="image">
                <img src={banner} alt="" />
              </div>
              <div className="text">
                <p>Siddharth Mishra</p>
                <i className="fa-sharp fa-regular fa-circle-check"></i>
              </div>
            </div>
            <div className="play">
              <button>
                Follow
                <i className="fa-solid fa-circle-plus"></i>
              </button>
            </div>
          </div>
          <div className="items">
            <div className="profile">
              <div className="image">
                <img src={banner} alt="" />
              </div>
              <div className="text">
                <p>Siddharth Mishra</p>
                <i className="fa-sharp fa-regular fa-circle-check"></i>
              </div>
            </div>
            <div className="play">
              <button>
                Follow
                <i className="fa-solid fa-circle-plus"></i>
              </button>
            </div>
          </div>
          <div className="items">
            <div className="profile">
              <div className="image">
                <img src={banner} alt="" />
              </div>
              <div className="text">
                <p>Siddharth Mishra</p>
                <i className="fa-sharp fa-regular fa-circle-check"></i>
              </div>
            </div>
            <div className="play">
              <button>
                Follow
                <i className="fa-solid fa-circle-plus"></i>
              </button>
            </div>
          </div>
        </div>
        {/* <!-- ********************************************************************* AUTHOR SECTION END *********************************************************************--> */}
      </div></motion.div >
  )
}

export default Trending